I like to suggest you do your development in loris-88 this time.

After unzipping the file in a directory. Please
perform "make" which will build an executable tut5.exe:

make

Run this executable, and place its output in
yourans.txt, as follows:

./tut5.exe > your_ans.txt

For editing, I suggest one of the following:
  vim
  gedit
  emacs

If you choose to use emacs, you can copy my
set-up by using the following:

hg clone ~chinwn/emacs
cd emacs
sh install.sh

You may call "emacs tut5.ml" to view 
your file. You may also get the following
cheatsheets:
 http://refcards.com/docs/gildeas/gnu-emacs/emacs-refcard-a4.pdf

For Ocaml mode, you can use the following cheatsheet:
 https://www.lri.fr/~filliatr/ens/compil/cards/tuareg-mode.pdf




